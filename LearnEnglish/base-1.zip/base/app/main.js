function main(){
	let g = new CustomGame(32,32,64);
}

window.onload = main;
